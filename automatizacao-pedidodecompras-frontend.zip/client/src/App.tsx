import LancaPC from './Sections/LancaPC';
import ImportaPlanilha from './Sections/ImportaPlanilha';
import ViewTabelaMensal from './Sections/ViewTabelaMensal';
import FilaLancamento from './Sections/FilaLancamento';
import VaccLogo from './Images/Vaccinar_negativo.png'
import React, { useState} from 'react';
import { CalendarOutlined, SendOutlined, CloudUploadOutlined, ClockCircleOutlined} from '@ant-design/icons';
import {Layout, Menu, App} from 'antd';

import type { MenuProps } from 'antd';

// Then use it like this:
type MenuItem = Required<MenuProps>['items'][number];

const {Content, Sider } = Layout;

function getItem(
  label: React.ReactNode,
  key: React.Key,
  icon?: React.ReactNode,
  children?: MenuItem[],
): MenuItem {
  return {
    key,
    icon,
    children,
    label,
  } as MenuItem;
}

const items: MenuItem[] = [
  getItem('Lançamento PC', '1', <SendOutlined />),
  getItem('Fila de Lançamento', '2', <ClockCircleOutlined />),
  getItem('Tabela Mensal', '3', <CalendarOutlined />),
  getItem('Importar Planilha', '4', <CloudUploadOutlined />)
];

const MyApp: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<string>('1'); // Track current page
  const [collapsed, setCollapsed] = useState<boolean>(false); // Track sidebar state

  const handleMenuClick = (e: any) => {
    setCurrentPage(e.key);
  };

  const handleCollapse = (collapsed: boolean) => {
    setCollapsed(collapsed);
  };

  const renderContent = () => {
    switch (currentPage) {
      case '1':
        return <LancaPC />;
      case '2':
        return <FilaLancamento />
      case '3':
        return <ViewTabelaMensal />;
      case '4':
        return <ImportaPlanilha />;
      default:
        return <LancaPC />;
    }
  };

  return (
    <>
    <App
      message={{
        maxCount: 3,
        duration: 7,
        top: 0,
      }}>
      <Layout style={{ minHeight: '100vh' }}>
        <Sider 
          collapsed={collapsed} 
          collapsible={true}
          onCollapse={handleCollapse}
        >
          <div style={{ position: 'sticky', top: 0 }}>
            <div style={{ 
              height: '64px', 
              display: 'flex', 
              alignItems: 'center', 
              justifyContent: 'center',
              backgroundColor: '#001529',
              borderBottom: '1px solid #303030'
            }}>
              {/* Logo - hide when collapsed */}
              {!collapsed && (
                <img 
                  src={VaccLogo}
                  alt="Company Logo" 
                  style={{ 
                    height: '60px', 
                    width: 'auto',
                    filter: 'brightness(0) invert(1)' // Makes logo white if it's dark
                  }} 
                />
              )}
              {/* Show smaller logo or icon when collapsed */}
              {collapsed && (
                <img 
                  src={VaccLogo}
                  alt="Company Logo" 
                  style={{ 
                    height: '40px', 
                    width: 'auto',
                    filter: 'brightness(0) invert(1)' // Makes logo white if it's dark
                  }} 
                />
              )}
            </div>
            <Menu 
              theme="dark" 
              selectedKeys={[currentPage]} 
              mode="inline" 
              items={items}
              onClick={handleMenuClick}
            />
          </div>
        </Sider>
        <Layout>
          <Content style={{ margin: '20px 20px' }}>
            {renderContent()}
          </Content>
        </Layout>
      </Layout>
      </App>
    </>
  );
};

export default MyApp;