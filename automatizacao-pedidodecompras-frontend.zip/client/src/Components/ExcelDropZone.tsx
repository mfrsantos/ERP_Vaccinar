import React, { useCallback, useState } from 'react';
import { read, utils } from 'xlsx';

type ExcelDropZoneProps = {
  onTableRead: (table: any[][]) => void;
};

const ExcelDropZone: React.FC<ExcelDropZoneProps> = ({ onTableRead }) => {
  const [isDragging, setIsDragging] = useState(false);

  const handleDrop = useCallback(async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (!file) return;
    const data = await file.arrayBuffer();
    const workbook = read(data);
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const table = utils.sheet_to_json(worksheet, { header: 1, raw: false });
    
    // Remove trailing empty rows and trim whitespace
    const cleanTable = (table as any[][])
        .map((row: any[]) => 
            row.map(cell => 
                typeof cell === 'string' ? cell.trim() : cell
            )
        )
        .filter((row: any[]) => {
            // Keep row if it has at least one non-empty cell
            return row.some(cell => 
                cell !== null && 
                cell !== undefined && 
                cell !== '' && 
                String(cell).trim() !== ''
            );
        });
    
    onTableRead(cleanTable);
}, [onTableRead]);

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
  };

 return (
    <div
      onDrop={handleDrop}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      style={{
        border: isDragging ? '3px solid #52c41a' : '2px solid #1890ff',
        borderRadius: 12,
        padding: 32,
        textAlign: 'center',
        background: isDragging 
          ? 'linear-gradient(135deg, #f6ffed 0%, #e6f7ff 100%)' 
          : 'linear-gradient(135deg, #fafafa 0%, #f0f2f5 100%)',
        color: isDragging ? '#52c41a' : '#1890ff',
        transition: 'all 0.3s ease',
        boxShadow: isDragging 
          ? '0 8px 25px rgba(82, 196, 26, 0.2), inset 0 1px 0 rgba(255, 255, 255, 0.1)' 
          : '0 4px 12px rgba(0, 0, 0, 0.08), inset 0 1px 0 rgba(255, 255, 255, 0.1)',
        fontFamily: 'Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif',
        fontSize: 16,
        fontWeight: 500,
        cursor: 'pointer',
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      <div style={{
        position: 'relative',
        zIndex: 1,
      }}>
        {isDragging ? '📁 Upload Planilha' : '⬆️ Arraste e solte o arquivo aqui para fazer o Upload'}
      </div>
      
      {/* Subtle animated background effect */}
      <div style={{
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: isDragging 
          ? 'radial-gradient(circle at center, rgba(82, 196, 26, 0.1) 0%, transparent 70%)'
          : 'radial-gradient(circle at center, rgba(24, 144, 255, 0.05) 0%, transparent 70%)',
        opacity: isDragging ? 1 : 0.5,
        transition: 'opacity 0.3s ease',
        pointerEvents: 'none',
      }} />
    </div>
  );
};

export default ExcelDropZone;