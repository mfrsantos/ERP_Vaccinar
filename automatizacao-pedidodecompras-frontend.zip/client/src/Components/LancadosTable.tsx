import React from 'react';
import { FilterOutlined } from '@ant-design/icons';
import { Table, Tag } from 'antd';
import type { TableColumnsType } from 'antd';


interface DataType {
  key: React.Key;
  filial: string;
  cod_fornecedor: string;
  cod_produto: string;
  fornecedor: string;
  dia_faturamento: string;
  cc: string;
  vencimento: string;
  valor_item: string;
  pedido_compra: string;
}


const columns: TableColumnsType<DataType> = [
  { title: 'Filial', dataIndex: 'filial', filterIcon: <FilterOutlined />, ellipsis: true, width: 80, sorter: (a, b) => Number(a.filial) - Number(b.filial) },
  { title: 'Nº PC', dataIndex: 'pedido_compra', filterIcon: <FilterOutlined />, ellipsis: true, width: 80, sorter: (a, b) => Number(a.pedido_compra) - Number(b.pedido_compra) },
  { title: 'Cod. Fornecedor', dataIndex: 'cod_fornecedor', filterIcon: <FilterOutlined />, ellipsis: true, width: 100, sorter: (a, b) => Number(a.cod_fornecedor) - Number(b.cod_fornecedor) },
  { title: 'Cod. Produto', dataIndex: 'cod_produto', filterIcon: <FilterOutlined />, ellipsis: true, width: 120, sorter: (a, b) => Number(a.cod_produto) - Number(b.cod_produto) },
  { title: 'Fornecedor', dataIndex: 'fornecedor', filterIcon: <FilterOutlined />, ellipsis: true, width: 120, sorter: (a, b) => a.fornecedor.localeCompare(b.fornecedor) },
  { title: 'C. Custos', dataIndex: 'cc', filterIcon: <FilterOutlined />, ellipsis: true, width: 120, sorter: (a, b) => Number(a.cc) - Number(b.cc) },
  { title: 'Vencimento', dataIndex: 'vencimento', filterIcon: <FilterOutlined />, ellipsis: true, width: 100, sorter: (a, b) => Number(a.vencimento) - Number(b.vencimento) },
  { title: 'Valor', dataIndex: 'valor_item', filterIcon: <FilterOutlined />, ellipsis: true, width: 100, sorter: (a, b) => Number(a.valor_item) - Number(b.valor_item) },
  {
    title: 'Lançamento',
    dataIndex: 'lancamento', 
    filterIcon: <FilterOutlined />, 
    width: 100,
    render: (value: string) => {
      const getBadgeProps = (lancamento: string) => {
        switch (lancamento?.toLowerCase()) {
          case 'manual':
            return { color: 'blue', text: 'Manual' };
          case 'auto':
            return { color: 'green', text: 'Automático' };
          default:
            return { color: 'default', text: value || 'N/A' };
        }
      };

      const { color, text } = getBadgeProps(value);
      
      return (
        <Tag color={color} style={{ margin: 0 }}>
          {text}
        </Tag>
      );
    }
  }
];

//   { title: 'PC', dataIndex: 'pedido_compra', filterIcon: <FilterOutlined />, ellipsis: true, width: 80 },

const LancadosTable: React.FC<any> = ({data}) => {

  return (
    <>
      <style>
        {`
          .ant-table-selection-column {
            width: 30px !important;
            min-width: 30px !important;
            max-width: 30px !important;
          }
        `}
      </style>
      <Table<DataType>
        bordered={true}
        pagination={{ pageSize: 15, position: ['bottomRight'] }}
        columns={columns}
        dataSource={data}
        scroll={{ x: 'max-content' }}
        showSorterTooltip={{ target: 'sorter-icon' }}
      />
    </>
  );
}

export default LancadosTable;