import React, { useState } from 'react';
import { FilterOutlined } from '@ant-design/icons';
import { Table, Input } from 'antd';
import type { TableColumnsType, TableProps } from 'antd';

type TableRowSelection<T extends object = object> = TableProps<T>['rowSelection'];

interface DataType {
  key: React.Key;
  filial: string;
  periodicidade: string;
  cod_fornecedor: string;
  cod_produto: string;
  fornecedor: string;
  faturamento: string;
  cc: string;
  vencimento: string;
  valor_item: string;
  pedido_compra: string;
}

interface PcTableProps {
  selectedRowKeys?: React.Key[];
  setSelectedRowKeys?: (keys: React.Key[]) => void;
  table : any;
}

const columns: TableColumnsType<DataType> = [
  { title: 'Filial', dataIndex: 'filial', filterIcon: <FilterOutlined />, ellipsis: true, width: 100,  sorter: (a, b) => Number(a.filial) - Number(b.filial) },
  { title: 'Periodicidade', dataIndex: 'periodicidade', filterIcon: <FilterOutlined />, ellipsis: true, width: 120, sorter: (a, b) => a.periodicidade.localeCompare(b.periodicidade) },
  { title: 'Cod. Fornecedor', dataIndex: 'cod_fornecedor', filterIcon: <FilterOutlined />, ellipsis: true, width: 120, sorter: (a, b) => Number(a.cod_fornecedor) - Number(b.cod_fornecedor) },
  { title: 'Cod. Produto', dataIndex: 'cod_produto', filterIcon: <FilterOutlined />, ellipsis: true, width: 120, sorter: (a, b) => Number(a.cod_produto) - Number(b.cod_produto) },
  { title: 'Fornecedor', dataIndex: 'fornecedor', filterIcon: <FilterOutlined />, ellipsis: true, width: 120, sorter: (a, b) => a.fornecedor.localeCompare(b.fornecedor) },
  { title: 'Faturamento', dataIndex: 'faturamento', filterIcon: <FilterOutlined />, ellipsis: true, width: 120, sorter: (a, b) => Number(a.faturamento) - Number(b.faturamento) },
  { title: 'C. Custos', dataIndex: 'cc', filterIcon: <FilterOutlined />, ellipsis: true, width: 120, sorter: (a, b) => Number(a.cc) - Number(b.cc) },
  { title: 'Vencimento', dataIndex: 'vencimento', filterIcon: <FilterOutlined />, ellipsis: true, width: 120, sorter: (a, b) => Number(a.vencimento) - Number(b.vencimento) },
  { title: 'Valor', dataIndex: 'valor_item', filterIcon: <FilterOutlined />, ellipsis: true, width: 120, sorter: (a, b) => Number(a.valor_item) - Number(b.valor_item) },
];

const EditableCell: React.FC<any> = ({ title, editable, children, dataIndex, record, handleSave, ...restProps }) => {
  const [editing, setEditing] = useState(false);
  const value = dataIndex && record ? record[dataIndex] : '';
  const [inputValue, setInputValue] = useState(value);
  const toggleEdit = () => {
    if (editable && dataIndex) {
      setEditing(true);
    }
  };

  const save = () => {
    setEditing(false);
    if (editable && dataIndex) {
      handleSave({ ...record, [dataIndex]: inputValue });
    }
  };

  return (
    <td
      {...restProps}
      onClick={toggleEdit}
      style={{
        cursor: editable && dataIndex ? 'pointer' : 'default',
        padding: '8px',
        minWidth: 100,
        boxSizing: 'border-box',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap',
      }}
    >
      {editable && editing && dataIndex ? (
        <Input
          value={inputValue}
          onChange={e => setInputValue(e.target.value)}
          onBlur={save}
          onPressEnter={save}
          autoFocus
          bordered={false}
          style={{
            width: '100%',
            background: 'transparent',
            padding: 0,
            minWidth: 80,
            maxWidth: '100%',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
          }}
        />
      ) : (
        <span style={{
          display: 'block',
          overflow: 'hidden',
          textOverflow: 'ellipsis',
          whiteSpace: 'nowrap',
        }}>{children}</span>
      )}
    </td>
  );
};

const PcTable: React.FC<PcTableProps> = ({ selectedRowKeys, setSelectedRowKeys, table }) => {
  
  const rowSelection: TableRowSelection<DataType> = selectedRowKeys && setSelectedRowKeys
    ? {
        selectedRowKeys,
        onChange: setSelectedRowKeys,
        columnWidth: 35
      }
    : undefined;

  return (
    <>
      <style>
        {`
          .ant-table-selection-column {
            width: 30px !important;
            min-width: 30px !important;
            max-width: 30px !important;
          }
        `}
      </style>
      <Table<DataType>
        bordered={true}
        rowSelection={rowSelection}
        pagination={{ pageSize: 5, position: ['bottomLeft'] }}
        columns={columns}
        dataSource={table}
        scroll={{ x: 'max-content' }}
        locale={{
            emptyText: 'Nenhuma despesa pendente encontrada'
          }}
        components={{
          body: {
            cell: EditableCell,
          },
        }}
      />
    </>
  );
}

export default PcTable;