import React, { useState, useRef, useEffect } from 'react';
import { Table, Input, Button, Popconfirm } from 'antd';
import type { TableColumnsType } from 'antd';
import type { PlanilhaRow } from '../Interfaces/rowPlanilha';

interface TabelaMensalProps {
  rows: PlanilhaRow[] | undefined | any;
  handleAdd : () => void;
  handleRemove : (key: React.Key) => void;
  onDataChange?: (newData: PlanilhaRow[]) => void;
}

const EditableCell: React.FC<any> = ({ title, editable, children, dataIndex, record, handleSave, ...restProps }) => {
  const [editing, setEditing] = useState(false);
  const value = dataIndex && record ? record[dataIndex] : '';
  const [inputValue, setInputValue] = useState(value);
  
  useEffect(() => {
    const currentValue = dataIndex && record ? record[dataIndex] : '';
    setInputValue(currentValue);
  }, [record, dataIndex]);
  
  const toggleEdit = () => {
    if (editable && dataIndex) {
      setEditing(true);
      const currentValue = record ? record[dataIndex] : '';
      setInputValue(currentValue);
    }
  };

  const save = () => {
    setEditing(false);
    if (editable && dataIndex) {
      handleSave({ ...record, [dataIndex]: inputValue });
    }
  };

    return (
      <td
        {...restProps}
        onClick={toggleEdit}
        style={{
          cursor: editable && dataIndex ? 'pointer' : 'default',
          padding: '8px',
          minWidth: 100,
          boxSizing: 'border-box',
          overflow: 'hidden',
          textOverflow: 'ellipsis',
          whiteSpace: 'nowrap',
          border: editable && editing && dataIndex ? '1px solid #1890ff' : 'inherit',
          backgroundColor: editable && editing && dataIndex ? '#f6ffed' : 'inherit',
        }}
      >
        {editable && editing && dataIndex ? (
          <Input
            value={inputValue}
            onChange={e => setInputValue(e.target.value)}
            onBlur={save}
            onPressEnter={save}
            autoFocus
            style={{
              width: '100%',
              background: 'transparent',
              padding: '4px 8px',
              minWidth: 80,
              maxWidth: '100%',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              whiteSpace: 'nowrap',
            }}
          />
        ) : (
          <span style={{
            display: 'block',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
          }}>{children}</span>
        )}
      </td>
    );
};


const TabelaMensal: React.FC<TabelaMensalProps> = ({ rows, handleAdd, handleRemove, onDataChange }) => {
  const [data, setData] = useState(rows);
  const tableRef = useRef<HTMLDivElement>(null);

  

  const columns: TableColumnsType<PlanilhaRow> = [
  { title: 'Filial', dataIndex: 'filial',  sorter: (a, b) => Number(a.filial) - Number(b.filial)},
  { title: 'Periodicidade', dataIndex: 'periodicidade',  sorter: (a, b) => a.periodicidade.localeCompare(b.periodicidade)},
  { title: 'Cod. Fornecedor', dataIndex: 'cod_fornecedor', sorter: (a, b) => Number(a.cod_fornecedor) - Number(b.cod_fornecedor)},
  { title: 'Cod. Produto', dataIndex: 'cod_produto', sorter: (a, b) => Number(a.cod_produto) - Number(b.cod_produto)},
  { title: 'Fornecedor', dataIndex: 'fornecedor', sorter: (a, b) => a.fornecedor.localeCompare(b.fornecedor)},
  { title: 'Faturamento', dataIndex: 'faturamento', sorter: (a, b) => Number(a.faturamento) - Number(b.faturamento)},
  { title: 'CC', dataIndex: 'cc', sorter: (a, b) => Number(a.cc) - Number(b.cc)},
  { title: 'Vencimento', dataIndex: 'vencimento', sorter: (a, b) => a.vencimento.localeCompare(b.vencimento)},
  { title: 'Valor', dataIndex: 'valor_item', sorter: (a, b) => Number(a.valor_item) - Number(b.valor_item)},
  { title: 'Lançamento', dataIndex: 'lancamento', sorter: (a, b) => a.lancamento.localeCompare(b.lancamento)},
  { title: 'Observação', dataIndex: 'obs', sorter: (a, b) => a.obs.localeCompare(b.obs)},
  { title: 'Ação', dataIndex: 'action', render: (_, record) =>
        data.length >= 1 ? (
          <Popconfirm title="Excluir Linha?" onConfirm={() => handleRemove(record.key)}>
            <a>Excluir</a>
          </Popconfirm>
        ) : null, },
  ];

  useEffect(() => {
    const tableContainer = tableRef.current;
    if (!tableContainer) return;

    const tableBody = tableContainer.querySelector('.ant-table-body');
    if (!tableBody) return;

    const handleWheel = (e: Event) => {
      const wheelEvent = e as WheelEvent;
      wheelEvent.preventDefault();
      tableBody.scrollLeft += wheelEvent.deltaY;
    };

    tableBody.addEventListener('wheel', handleWheel, { passive: false });
    return () => tableBody.removeEventListener('wheel', handleWheel);
  }, []);

  const handleSave = (row: PlanilhaRow) => {
    const newData = [...(data || [])];
    const index = newData.findIndex(item => item.key === row.key);

    if (index > -1) {
        const oldRow = newData[index];
        
        const trimmedRow = Object.keys(row).reduce((acc, key) => {
            const value = row[key as keyof PlanilhaRow];
            (acc as any)[key] = typeof value === 'string' ? value.trim() : value;
            return acc;
        }, { ...row });
        
        const hasChanged = JSON.stringify(oldRow) !== JSON.stringify(trimmedRow);
        
        if (hasChanged) {
            newData[index] = trimmedRow;
            setData(newData);
            
            if (onDataChange) {
                onDataChange(newData);
            }
        }
    }
  };
  useEffect(() => {
    setData(rows);
  }, [rows]);

  const editableColumns = columns.map(col => {
    if (col.title === 'Ação') {return col}
    if ('dataIndex' in col && typeof col.dataIndex === 'string') {
      return {
        ...col,
        onCell: (record: PlanilhaRow) => ({
          record,
          editable: true,
          dataIndex: col.dataIndex,
          title: typeof col.title === 'string' ? col.title : '',
          handleSave,
        })
      };
    }
    return col;
  });

  return (
    <div ref={tableRef} style={{ overflowX: 'auto', width: '100%', maxWidth: '100vw' }}>
      <style>
        {`
          .ant-table-selection-column {
            width: 30px !important;
            min-width: 30px !important;
            max-width: 30px !important;
          }
          
          /* Excel-like borders */
          .ant-table-bordered .ant-table-tbody > tr > td {
            border-right: 1px solid #d9d9d9 !important;
            border-bottom: 1px solid #d9d9d9 !important;
          }
          
          .ant-table-bordered .ant-table-thead > tr > th {
            border-right: 1px solid #d9d9d9 !important;
            border-bottom: 1px solid #d9d9d9 !important;
          }
          
          .ant-table-bordered .ant-table-tbody > tr:last-child > td {
            border-bottom: 1px solid #d9d9d9 !important;
          }
          
          .ant-table-bordered .ant-table-thead > tr:last-child > th {
            border-bottom: 2px solid #d9d9d9 !important;
          }
          
          /* Remove double borders */
          .ant-table-bordered .ant-table-container {
            border-left: 1px solid #d9d9d9;
            border-top: 1px solid #d9d9d9;
          }
          
          .ant-table-bordered .ant-table-tbody > tr > td:first-child,
          .ant-table-bordered .ant-table-thead > tr > th:first-child {
            border-left: none;
          }
          
          .ant-table-bordered .ant-table-tbody > tr:first-child > td,
          .ant-table-bordered .ant-table-thead > tr:first-child > th {
            border-top: none;
          }
        `}
      </style>
      <Table<PlanilhaRow>
        bordered={true}
        columns={editableColumns}
        pagination={false}
        dataSource={data}
        scroll={{ x: 1200 }}
        components={{
          body: {
            cell: EditableCell,
          },
        }}
      />
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 0 }}>
        <Button onClick={handleAdd} type="dashed" style={{ marginTop: 20 }}>
          +
        </Button>
      </div>
    </div>
  );
}

export default TabelaMensal;