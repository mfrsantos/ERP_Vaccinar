import React, { useState, useEffect, useCallback } from 'react';
import { Card, Collapse, Table, Tag, Spin, Typography, Space } from 'antd';
import { CaretRightOutlined, ClockCircleOutlined, CheckCircleOutlined, ExclamationCircleOutlined } from '@ant-design/icons';
import AppConfig from '../Config/AppConfig';


const { Panel } = Collapse;
const { Text } = Typography;
const setor = AppConfig.setor;

interface TaskStep {
  filial: string;
  periodicidade: string;
  cod_fornecedor: string;
  cod_produto: string;
  fornecedor: string;
  faturamento: string;
  cc: string;
  vencimento: string;
  valor_item: string; 
  lancamento: string;
  obs: string;
  status?: 'pending' | 'started' | 'success' | 'failed';
}

interface QueueTask {
  task_id?: string;
  setor: string;
  steps: TaskStep[];
  status?: 'pending' | 'started' | 'success' | 'failed';
  created_at?: string;
  total_items?: number;
  processed_items?: number;
  tipo_operacao?: string;
}

const useAutoRefresh = (
  queueData: QueueTask[], 
  fetchFunction: () => void, 
  intervalMs: number = 5000
) => {
  useEffect(() => {
    const hasActiveTasks = queueData.some(task => 
      task.status === 'pending' || task.status === 'started' ||
      task.steps.some(step => 
        step.status === 'pending' || step.status === 'started' || !step.status
      )
    );

    if (hasActiveTasks) {
      const interval = setInterval(() => {
        fetchFunction();
      }, intervalMs);

      return () => clearInterval(interval);
    }
  }, [queueData, fetchFunction, intervalMs]);
};

const FilaLancamento: React.FC = () => {
  const [queueData, setQueueData] = useState<QueueTask[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [activeKey, setActiveKey] = useState<string | string[]>([]);

  const fetchQueueData = useCallback(async (showLoading: boolean = false) => {
    try {
      // Only show loading on manual refresh or initial load
      if (showLoading) {
        setLoading(true);
      }

      const response = await fetch(`${AppConfig.locations.api.tasksRecentes}/${setor}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      if (response.ok) {
        const data = await response.json();
        if (data.status === 'sucesso') {
          // Transform the data to match the expected structure
          const transformedTasks = data.tasks?.map((task: any, index: number) => {
            const steps = task.steps || [];
            
            // Calculate processed items (success + failed)
            const processedItems = steps.filter((step: TaskStep) => 
              step.status === 'success' || step.status === 'failed'
            ).length;

            // Determine task status based on step statuses
            const taskStatus = determineTaskStatus(steps, task.status);
            
            return {
              task_id: task._id || `task_${index + 1}`,
              setor: task.setor,
              steps: steps,
              status: taskStatus,
              created_at: task.created_at || new Date().toISOString(),
              total_items: steps.length,
              processed_items: processedItems,
              tipo_operacao: task.tipo || ''
            };
          });

          // Only update state if data has actually changed
          const newDataString = JSON.stringify(transformedTasks || []);
          const currentDataString = JSON.stringify(queueData);
          
          if (newDataString !== currentDataString) {
            setQueueData(transformedTasks || []);
          }
        }
      }
    } catch (error) {
      console.error('Error fetching queue data:', error);
    } finally {
      if (showLoading) {
        setLoading(false);
      }
    }
  }, [queueData]); 

  const autoFetchQueueData = useCallback(() => {
    fetchQueueData(false);
  }, [fetchQueueData]);

  useEffect(() => {
    fetchQueueData(true); 
  }, []); 

  useAutoRefresh(queueData, autoFetchQueueData, 5000);

  const determineTaskStatus = (steps: TaskStep[], originalStatus?: string) => {
    if (steps.length === 0) return 'pending';
    
    const pendingCount = steps.filter(step => step.status === 'pending' || !step.status).length;
    const startedCount = steps.filter(step => step.status === 'started').length;
    const successCount = steps.filter(step => step.status === 'success').length;
    const failedCount = steps.filter(step => step.status === 'failed').length;
    
    // If there are any started items, task is processing
    if (startedCount > 0) {
      return 'started';
    }
    
    // If there are pending items, task is pending
    if (pendingCount > 0) {
      return 'pending';
    }
    
    // All items are processed (success or failed)
    if (pendingCount === 0 && startedCount === 0) {
      // If all items succeeded
      if (failedCount === 0) {
        return 'success';
      }
      // If some failed but task is considered complete
      else if (successCount > 0) {
        return 'success'; // Task completed with some failures
      }
      // If all failed
      else {
        return 'failed';
      }
    }
    
    return originalStatus || 'pending';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'orange';
      case 'started': return 'blue';
      case 'success': return 'green';
      case 'failed': return 'red';
      default: return 'default';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending': return <ClockCircleOutlined />;
      case 'started': return <ClockCircleOutlined spin />;
      case 'success': return <CheckCircleOutlined />;
      case 'failed': return <ExclamationCircleOutlined />;
      default: return null;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending': return 'Pendente';
      case 'started': return 'Processando';
      case 'success': return 'Concluído';
      case 'failed': return 'Falhou';
      default: return status;
    }
  };

  // Columns for the nested steps table
  const stepColumns = [
    {
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
      width: 100,
      render: (status: string) => {
        const getStepStatusColor = (stepStatus: string) => {
          switch (stepStatus) {
            case 'pending': return '#faad14'; // orange
            case 'started': return '#1890ff'; // blue
            case 'success': return '#52c41a'; // green
            case 'failed': return '#ff4d4f'; // red
            default: return '#d9d9d9'; // gray
          }
        };

        const getStepStatusText = (stepStatus: string) => {
          switch (stepStatus) {
            case 'pending': return 'Pendente';
            case 'started': return 'Processando';
            case 'success': return 'Concluído';
            case 'failed': return 'Falhou';
            default: return 'Pendente';
          }
        };

        return (
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <div
              style={{
                width: '8px',
                height: '8px',
                borderRadius: '50%',
                backgroundColor: getStepStatusColor(status || 'pending'),
                display: 'inline-block'
              }}
            />
            <span style={{ fontSize: '12px', color: '#666' }}>
              {getStepStatusText(status || 'pending')}
            </span>
          </div>
        );
      },
    },
    {
      title: 'Filial',
      dataIndex: 'filial',
      key: 'filial',
      width: 100,
    },
    {
      title: 'Periodicidade',
      dataIndex: 'periodicidade',
      key: 'periodicidade',
      width: 120,
    },
    {
      title: 'Cód. Fornecedor',
      dataIndex: 'cod_fornecedor',
      key: 'cod_fornecedor',
      width: 130,
    },
    {
      title: 'Cód. Produto',
      dataIndex: 'cod_produto',
      key: 'cod_produto',
      width: 120,
    },
    {
      title: 'Fornecedor',
      dataIndex: 'fornecedor',
      key: 'fornecedor',
      width: 200,
    },
    {
      title: 'Faturamento',
      dataIndex: 'faturamento',
      key: 'faturamento',
      width: 100,
    },
    {
      title: 'CC',
      dataIndex: 'cc',
      key: 'cc',
      width: 100,
    },
    {
      title: 'Vencimento',
      dataIndex: 'vencimento',
      key: 'vencimento',
      width: 100,
    },
    {
      title: 'Valor',
      dataIndex: 'valor_item',
      key: 'valor_item',
      width: 120,
    },
    {
      title: 'Lançamento',
      dataIndex: 'lancamento',
      key: 'lancamento',
      width: 100,
      render: (value: string) => (
        <Tag color={value === 'manual' ? 'blue' : 'green'}>
          {value === 'manual' ? 'Manual' : 'Automático'}
        </Tag>
      ),
    },
    {
      title: 'Observações',
      dataIndex: 'obs',
      key: 'obs',
      width: 150,
      render: (value: string) => (
        <div style={{ 
          maxWidth: '150px', 
          overflow: 'hidden', 
          textOverflow: 'ellipsis',
          whiteSpace: 'nowrap'
        }} title={value}>
          {value || '-'}
        </div>
      ),
    },
  ];

  const renderTaskHeader = (task: QueueTask) => {
    const successCount = task.steps.filter(step => step.status === 'success').length;
    const failedCount = task.steps.filter(step => step.status === 'failed').length;
    const processingCount = task.steps.filter(step => step.status === 'started').length;
    
    return (
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', width: '100%' }}>
        <Space>
          <Tag color={getStatusColor(task.status || 'pending')} icon={getStatusIcon(task.status || 'pending')}>
            {getStatusText(task.status || 'pending')}
          </Tag>
          <Text strong>Task #{task.task_id || 'N/A'}</Text>
          <Text type="secondary">{task.tipo_operacao || 'Processamento'}</Text>
          <Text type="secondary">({task.setor})</Text>
        </Space>
        <Space>
          <Text type="secondary">
            {task.processed_items || 0}/{task.total_items || task.steps.length} processados
          </Text>
          {successCount > 0 && (
            <Text style={{ color: '#52c41a' }}>
              ✓ {successCount}
            </Text>
          )}
          {failedCount > 0 && (
            <Text style={{ color: '#ff4d4f' }}>
              ✗ {failedCount}
            </Text>
          )}
          {processingCount > 0 && (
            <Text style={{ color: '#1890ff' }}>
              ⟳ {processingCount}
            </Text>
          )}
        </Space>
      </div>
    );
  };

  const renderTaskContent = (task: QueueTask) => {
    return (
      <div>
        <Table
          columns={stepColumns}
          dataSource={task.steps.map((step, index) => ({ 
            ...step, 
            key: `${task.task_id || 'Tarefa'}-Passo-${index}` 
          }))}
          pagination={{ pageSize: 10, showSizeChanger: false }}
          size="small"
          bordered
          scroll={{ x: 800 }}
          locale={{ emptyText: 'Nenhum step encontrado' }}
        />
      </div>
    );
  };

  if (loading) {
    return (
      <div style={{ 
        display: 'flex', 
        justifyContent: 'center', 
        alignItems: 'center', 
        height: '300px' 
      }}>
        <Spin size="large" tip="Carregando fila de processamento..." />
      </div>
    );
  }

  // Check if there are any pending or processing tasks for the header tag
  const hasActiveTasks = queueData.some(task => 
    task.status === 'pending' || task.status === 'started' ||
    task.steps.some(step => 
      step.status === 'pending' || step.status === 'started' || !step.status
    )
  );

  return (
    <div>
        <Typography.Title 
          level={2} 
          style={{ 
            margin: 0, 
            borderBottom: '3px solid #1890ff', 
            paddingBottom: 16,
            background: 'linear-gradient(145deg, #1890ff 0%, #722ed1 100%)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text'
          }}
        >
          Fila de Lançamento
        </Typography.Title>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
          <div></div>
          <Space>
          {hasActiveTasks && (
            <Tag color="blue" icon={<ClockCircleOutlined spin />} style={{ marginTop: '2px' }}>
              Em progresso...
            </Tag>
          )}
        </Space>
        </div>

      {queueData.length === 0 ? (
        <Card>
          <div style={{ textAlign: 'center', padding: '40px 0', color: '#999' }}>
            <div style={{ fontSize: '16px', marginBottom: '8px' }}>
              📋 Nenhuma task na fila
            </div>
            <div style={{ fontSize: '14px' }}>
              Todas as operações foram processadas
            </div>
          </div>
        </Card>
      ) : (
        <Collapse
          activeKey={activeKey}
          onChange={setActiveKey}
          expandIcon={({ isActive }) => <CaretRightOutlined rotate={isActive ? 90 : 0} />}
          size="large"
        >
          {queueData.map((task, index) => (
            <Panel
              header={renderTaskHeader(task)}
              key={task.task_id || `task-${index}`}
              style={{ marginBottom: 8 }}
            >
              {renderTaskContent(task)}
            </Panel>
          ))}
        </Collapse>
      )}
    </div>
  );
};

export default FilaLancamento;