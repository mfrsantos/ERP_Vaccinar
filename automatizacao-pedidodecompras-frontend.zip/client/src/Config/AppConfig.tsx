type featureFlag = 'local' | 'production';
var AppConfig : {
    state: featureFlag;
    locations: {
        authApi: string;
        api: {
            tabelaMensal: string;
            novaTabelaMensal : string;
            datetime : string;
            tabelaMensalManual : string;
            novaTask : string;
            tasksRecentes : string;
            pcsLancadosMesAno : string;
            pcsLancadosRows : string;
        };
    };
    setor : string;
} = {
    state: 'production',
    locations: {
        authApi: '',
        api: {
            tabelaMensal: '',
            novaTabelaMensal: '',
            datetime: '',
            tabelaMensalManual: '',
            novaTask: '',
            tasksRecentes: '',
            pcsLancadosMesAno: '',
            pcsLancadosRows: ''
        }
    },
    setor : ''
};

//UTILIZAR FEATURE FLAG PARA DESENVOLVIMENTO LOCAL!
const AppState : featureFlag = 'production';

/*
if(AppState !== 'production') {
    AppConfig  = {
        state : 'local',
        locations: {
            authApi : 'http://localhost:8000',
            api : {
                tabelaMensal: 'http://localhost:8000/pedidodecompras/tabelamensal', //{setor}
                novaTabelaMensal : 'http://localhost:8000/pedidodecompras/tabelamensal/nova',
                datetime : 'http://localhost:8000/datetime',
                tabelaMensalManual : 'http://localhost:8000/pedidodecompras/tabelamensal/manual', //{setor}
                novaTask : 'http://localhost:8000/pedidodecompras/task/nova',
                tasksRecentes : 'http://localhost:8000/pedidodecompras/tasks/recent', //{setor}
                pcsLancadosMesAno : 'http://localhost:8000/pedidodecompras/lancados',
                pcsLancadosRows : 'http://localhost:8000/pedidodecompras/lancados/rows'
            }
        }
    }
}

*/

if (AppState === 'production') {
    AppConfig  = {
        state : 'production',
        locations: {
            authApi : 'https://api.example.com',
            api : {
                tabelaMensal: 'https://aplic.vaccinar.com.br:8666/pcapi/pedidodecompras/tabelamensal',
                novaTabelaMensal : 'https://aplic.vaccinar.com.br:8666/pcapi/pedidodecompras/tabelamensal/nova',
                datetime : 'https://aplic.vaccinar.com.br:8666/pcapi/datetime',
                tabelaMensalManual : 'https://aplic.vaccinar.com.br:8666/pcapi/pedidodecompras/tabelamensal/manual',
                novaTask : 'https://aplic.vaccinar.com.br:8666/pcapi/pedidodecompras/task/nova',
                tasksRecentes : 'https://aplic.vaccinar.com.br:8666/pcapi/pedidodecompras/tasks/recent',
                pcsLancadosMesAno : 'https://aplic.vaccinar.com.br:8666/pcapi/pedidodecompras/lancados',
                pcsLancadosRows : 'https://aplic.vaccinar.com.br:8666/pcapi/pedidodecompras/lancados/rows'
            }
        },
        setor : 'TI'
    }
}

export default AppConfig;