export interface PlanilhaRow {
  key: React.Key;
  filial: string;
  periodicidade: string;
  cod_fornecedor: string;
  cod_produto: string;
  fornecedor: string;
  faturamento: string;
  cc: string;
  vencimento: string;
  valor_item: string;
  lancamento: string;
  obs:string;
}
