import TaskCard from '../Components/TaskCard';

function FilaLancamento() {
    return (
        <TaskCard />
    )
}

export default FilaLancamento;