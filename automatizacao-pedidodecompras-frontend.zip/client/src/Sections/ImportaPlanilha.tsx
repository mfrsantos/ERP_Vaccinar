import { Card, Space, Typography, Button, App } from 'antd';
import {useEffect, useState} from 'react'
import TabelaMensal from '../Components/TabelaMensal';
import ExcelDropZone from '../Components/ExcelDropZone';
import AppConfig from '../Config/AppConfig';

const setor = AppConfig.setor;

const example_rows = [{
    key: '1',
    filial: '010001',
    periodicidade: 'Mensal',
    cod_fornecedor: '005700',
    cod_produto: '7800000',
    fornecedor: 'Totvs',
    faturamento: '5',
    cc: '140502',
    vencimento: '20',
    valor_item: '650.00',
    obs: 'Observação exemplo - A mesma observação do pedido de compra',
    lancamento: 'auto',
    }];

const convertCommaToDot = (value: string) => {
    return value.replace(',', '.');
};

const ImportaPlanilha = () => {
    const { message } = App.useApp();
    const [table, setTable] = useState<any[][]>([])
    const [readyTable, setReadytable] = useState<object[]>([]);
    const [readyTableLoaded, setReadyTableLoaded] = useState<boolean>(false);
    const [upload, setUpload] = useState<boolean>(false);
    const [firstLoad, setFirstLoad] = useState<boolean>(true);

    // Custom message with more prominent styling
    const showSuccessMessage = (content: string) => {
        message.success(content);
    };

    const showErrorMessage = (content: string) => {
        message.error(content);
    };

    async function sendNewPlanilhatoServer() {

        try {
            const res = await fetch(
                AppConfig.locations.api.novaTabelaMensal,
                {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        setor: setor,
                        rows: readyTable
                    })
            });
            if (res) {
                const content = await res.json();
                if (content.status === 'sucesso') {
                    showSuccessMessage('Planilha cadastrada com sucesso! Você pode conferir os dados inseridos na aba "Tabela Mensal".');
                    setUpload(false)
                    setReadyTableLoaded(false)
                } else {
                    showErrorMessage(`Erro ao cadastrar planilha: ${content.msg}`);
                }
            }
        }    

        catch (error) {
        }
    }

    const renderTableAndButtonUpload = () => {
        // Map the readyTable data to add keys for the table component
        const tableDataWithKeys = readyTable.map((row, index) => ({
            key: index + 1,
            ...row
        }));

        return (
            <>
            <div style={{marginTop: '20px', paddingLeft: '20px', paddingRight: '20px'}}>
                <TabelaMensal rows={tableDataWithKeys} handleRemove={() => {}} handleAdd={() => {}} />
            </div>
            <div style={{ textAlign: 'right', paddingRight: '10px', marginTop: '30px' }}>
                <Button type="primary" style={{height: '45px'}} onClick={() => {sendNewPlanilhatoServer()}}>
                    Cadastrar Planilha
                </Button>
            </div>
            <div style={{ color: 'red', paddingLeft: '20px', paddingRight: '20px', marginTop: '10px' }}>
                * ATENÇÃO: Se houver tabela já cadastrada no app, esse cadastro irá substituí-la. 
            </div>
            </>
        );
    }

    useEffect(() => {
        if(!upload){return}
        var finaltable = [];
        for (var i = 1; i < table.length; i++) {
        finaltable[i-1] = {
            filial: table[i][0],
            periodicidade: table[i][1],
            cod_fornecedor: table[i][2],
            cod_produto: table[i][3],
            fornecedor: table[i][4],
            faturamento: table[i][5],
            cc: table[i][6],
            vencimento: table[i][7],
            valor_item: convertCommaToDot(table[i][8]),
            lancamento: table[i][9],
            obs: table[i][10],
        }
        }
        setReadytable(finaltable);
        setReadyTableLoaded(true);
        message.success('Planilha carregada com sucesso!');
    }, [upload])

    useEffect(() => {
        if (readyTableLoaded) {
            // Wait for the component to render before scrolling
            setTimeout(() => {
                window.scrollTo({
                    top: document.documentElement.scrollHeight,
                    behavior: 'smooth'
                });
            }, 50);
        }

        else {
                setTimeout(() => {
                window.scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });
            }, 50);
        }
    }, [readyTableLoaded]);

    useEffect(() => {
        if (firstLoad){
            setFirstLoad(false);
            return;
        }
        setUpload(true);
    }, [table])


    return (
        <Space direction="vertical" size="large" style={{ width: '100%' }}>
            <div style={{}}> {/* Negative margin to pull card closer */}
                <Typography.Title 
                    level={2} 
                    style={{ 
                        margin: 0, 
                        marginLeft: 20, 
                        borderBottom: '3px solid #1890ff', 
                        paddingBottom: 16,
                        background: 'linear-gradient(135deg, #1890ff 0%, #722ed1 100%)',
                        WebkitBackgroundClip: 'text',
                        WebkitTextFillColor: 'transparent',
                        backgroundClip: 'text'
                    }}
                >
                    Importar planilha de Despesas do Setor
                </Typography.Title>
            </div>
            <Card style={{ marginTop: 15 }}>
                <div style={{ 
                    fontSize: '16px',
                    marginLeft : '20px',
                    marginRight: '20px',
                    marginBottom: '10px',
                    lineHeight: '1.6',
                    color: '#424242ff',
                    padding: '16px 0'
                }}>
                &nbsp;&nbsp;Por meio desse assitente, você consegue configurar o funcionamento do aplicativo através de uma planilha de despesas já existente. Para isso, basta que os títulos das colunas da planilha correspondam aos campos da tabela a seguir:
                </div>
                <div style={{paddingLeft: '20px', paddingRight: '20px'}}>
                    <TabelaMensal rows={example_rows} handleAdd={()=> {}} handleRemove={() => {}} />
                </div>
                    <div style={{ 
                    marginTop: '10px',
                    marginLeft : '20px',
                    marginRight: '20px',
                    fontSize: '16px',
                    lineHeight: '1.6',
                    color: '#424242ff',
                    padding: '16px 0'
                }}>
                &nbsp;&nbsp;Além disso, para que o lançamento automático dos pedidos de compra funcione corretamente, é necessário observar algumas regras no preenchimento de cada um dos campos. Certifique-se de que os dados estejam devidamente formatados e que não haja informações inconsistentes ou faltantes. As regras à seguir detalham o preenchimento de cada campo:
                </div>
                <ul style={{ paddingLeft: '20px',      
                    marginTop: "1px", 
                    marginLeft : '60px',            
                    lineHeight: '1.6',
                    color: '#424242ff',
                    fontSize: '15px'
                }}>
                    <li>Filial: Utilizar o código de filial numérico do Protheus. O código deve sempre possuir 6 dígitos.</li>
                    <li>Periodicidade: Utilizar um dos valores textuais: "Mensal", "Anual", "Trimestral", "Avulso"</li>
                    <li>Cod. Fornecedor: Mesmo código de fornecedor utilizado no Protheus.</li>
                    <li>Cod. Produto: Mesmo código de produto utilizado no Protheus.</li>
                    <li>Dia de Faturamento: Deve ser um número entre 1 e 31.</li>
                    <li>Centro de Custos: Mesmo centro de custos utilizado no Protheus.</li>
                    <li>Vecimento: Prazo da emissão até o vencimento. Utilizar número.</li>
                    <li>Valor: Deve ser um número positivo com vírgula separando as casas decimais.</li>
                    <li>Lançamento: Um dos valores: 1: 'auto', 2: 'manual', 3: 'info'. Para 'auto', o aplicativo irá agendar o lançamento do registro no início de cada mês. Para 'manual', o usuário do app poderá lançar o registro via a aba de Lançamento de PC. Para a opção 'info', o app irá somente registrar os valores, mas não irá realizar nenhum tipo de lançamento.  </li>
                </ul>
            <div style={{ 
                    marginTop: '40px', width: '80%', marginLeft: 'auto', marginRight: 'auto'}}>
            <ExcelDropZone onTableRead={setTable}/>
            </div>
            {(readyTableLoaded)? renderTableAndButtonUpload() : null}
            </Card>
        </Space>)
    }

export default ImportaPlanilha;