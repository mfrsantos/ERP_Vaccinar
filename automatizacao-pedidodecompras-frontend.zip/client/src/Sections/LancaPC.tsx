import PcTable from '../Components/PendentesTable';
import LancadosTable from '../Components/LancadosTable'
import { Card, Space, Typography, Button, Row, Col, Spin, App } from 'antd';
import React, { useState, useEffect} from 'react';
import AppConfig from '../Config/AppConfig';

const setor = AppConfig.setor;

const fetchDatetime = async () => {
    const res = await fetch(AppConfig.locations.api.datetime, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    });
    const api_response = await res.json();
    return api_response;
}

const fetchPcsLancados = async ({mesAno} : {mesAno : string}) => {
    const res = await fetch(`${AppConfig.locations.api.pcsLancadosMesAno}/${setor}/${mesAno}`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    });
    const api_response = await res.json();
    return api_response;

}

const fetchPcsLancadosRows = async ({mesAno} : {mesAno : string}) => {
    const res = await fetch(`${AppConfig.locations.api.pcsLancadosRows}/${setor}/${mesAno}`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    });
    const api_response = await res.json();
    return api_response;

}

interface lancadosTableprops {
    count : number
    key : string
    lancamento : string
}

const buildPcsLancadosTable = ({data} : {data : lancadosTableprops[]}) => {
    var pc_table : {[key: string]: number} = {};
    for (var i = 0; i < data.length; i++) {
        if (data[i].lancamento === 'manual') {
            pc_table[data[i].key] = data[i].count;
        }
    }
    return pc_table;
}

const removerPcsJaLancados = ({pcLancadosTable, resposta_api_rows} : {pcLancadosTable : any, resposta_api_rows : any}) => {
    var allowedPcsArray = []
    console.log(resposta_api_rows)

    for(var i = 0; i < resposta_api_rows.length; i++) {
        var key = `${resposta_api_rows[i]['filial']}_${resposta_api_rows[i]['cod_fornecedor']}_${resposta_api_rows[i]['cod_produto']}_${resposta_api_rows[i]['valor_item']}_${resposta_api_rows[i]['cc']}`;
        if (pcLancadosTable.hasOwnProperty(key)) {
            if(pcLancadosTable[key] > 0) {
                console.log(pcLancadosTable[key])
                pcLancadosTable[key]--;
            }
            else {
                allowedPcsArray.push(resposta_api_rows[i]);
            }
        }
        else {
            allowedPcsArray.push(resposta_api_rows[i]);
        }

    }
    return allowedPcsArray
}

function LancaPC() {
    const [selectedRowKeys, setSelectedRowKeys] = useState<React.Key[]>([]);

    interface pcManualDataprops {
        key : number
    }
    const [pcManualData, setPcManualData] = useState<pcManualDataprops[]>([]);
    const [pcData, setPcData] = useState<object[]>([]);
    const [pcsLancadosData, setPcsLancadosData] = useState<any[]>([]);
    const [loading, setLoading] = useState<boolean>(true);

    const { message } = App.useApp();

    // Custom message with more prominent styling
    const showSuccessMessage = (content: string) => {
        message.success(content);
    };

    const showErrorMessage = (content: string) => {
        message.error(content);
    };

    const lancaPcsMarcados = async () => {
        const finalData = pcData.map((row :any) => {
            var data = {...row}
            delete data.key; // Remove the key property
            return data;
        })

        const res = await fetch(`${AppConfig.locations.api.novaTask}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                setor: setor,
                rows: finalData
            })
        });
        const api_response = await res.json();  
        if(api_response.status === 'sucesso') {
            showSuccessMessage('A tarefa de lançamento dos pedidos de compra foi adicionada à fila com sucesso.')
            setSelectedRowKeys([])
        }
        else{
            showErrorMessage('Ocorreu um erro ao adicionar o lançamento dos pedidos de compra à fila.')
        }
    }

    const getPCsLancamentoManual= async ({setPcManualData} : {setPcManualData : any}) => {
        const res = await fetch(`${AppConfig.locations.api.tabelaMensalManual}/${setor}`,
        {
            method: 'GET',
            headers: {
            'Content-Type': 'application/json'
            },
            credentials: 'include'
        }
        )
        const resposta_api = await res.json();
        const datetime = await fetchDatetime();

        if (!(datetime.status === 'sucesso')) {
            setPcManualData([])
            showErrorMessage('Não foi possível obter a data/hora atual.')
            return
        }

        //const dia = datetime.dia;
        const mes = datetime.mes;
        const ano = datetime.ano;

        const mesAno = `${mes}-${ano}`;

        const pcsLancados = await fetchPcsLancados({mesAno});
        if (!(pcsLancados.status === 'sucesso')) {
            
            if (!(pcsLancados.detail.tipo === 'not_found')){
            setPcManualData([])
            showErrorMessage('Erro ao obter os pedidos de compra lançados. Impossível prosseguir.')
            return
            }
            pcsLancados.data = []
        }

        const pcLancadosTable = buildPcsLancadosTable({data: pcsLancados.data})

        var rows = resposta_api.rows

        const pcsPermitidos = removerPcsJaLancados({pcLancadosTable: pcLancadosTable, resposta_api_rows: rows});
        console.log(pcsPermitidos)

        fetchPcsLancadosRows({mesAno})
            .then((res) => {
                if (res.status === 'sucesso') {
                    setPcsLancadosData(res.data)
                } 
        });



        const new_data = pcsPermitidos.map((row : any, index : number) => {
            return {
                key: index,
                ...row
            };
        });

        setPcManualData(new_data);
    }

    useEffect(() => {
        setLoading(true);
        getPCsLancamentoManual({setPcManualData})
            .finally(() => setLoading(false));
    }, []);

    useEffect(() => {
        if (selectedRowKeys.length > 0) {
            const data = pcManualData.filter(item => selectedRowKeys.includes(item.key));
            setPcData(data);
        }
    }, [selectedRowKeys]);

    return (
        <Space direction="vertical" size="large" style={{ width: '100%' }}>
            <Typography.Title 
                level={2} 
                style={{ 
                    margin: 0, 
                    marginLeft: 20, 
                    borderBottom: '3px solid #1890ff', 
                    paddingBottom: 16,
                    background: 'linear-gradient(135deg, #1890ff 0%, #722ed1 100%)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                    backgroundClip: 'text'
                }}
            >
                Lançamento Manual de Pedidos de Compra
            </Typography.Title>
            
            <Card style={{ overflow: 'hidden' , marginTop: '10px'}}>
                <Typography.Title 
                    level={3} 
                    style={{ 
                        margin: 0, 
                        marginBottom: 20, 
                        borderBottom: '2px solid #f0f0f0', 
                        paddingBottom: 12,
                        color: '#595959',
                        fontWeight: 600
                    }}
                >
                    Despesas não Lançadas
                </Typography.Title>
                <Row align="middle" justify="space-between">
                    <Col></Col>
                </Row>
                {loading ? (
                    <div style={{ 
                        display: 'flex', 
                        justifyContent: 'center', 
                        alignItems: 'center', 
                        height: '200px' 
                    }}>
                        <Spin size="large" tip="Carregando dados..." />
                    </div>
                ) : (
                    <div style={{ 
                        overflowX: 'auto',
                        width: '100%',
                        maxWidth: '100%'
                    }}>
                        <PcTable
                            table = {pcManualData}
                            selectedRowKeys={selectedRowKeys}
                            setSelectedRowKeys={setSelectedRowKeys}
                        />
                    </div>
                )}
                <Row align="middle" justify="space-between" style={{marginTop: 20}}>
                    <Col></Col>
                    <Col>
                        {selectedRowKeys.length > 0 && (
                            <Button type="primary" onClick={() => lancaPcsMarcados()} >
                                Lançar Pedidos Selecionados ({selectedRowKeys.length}) 
                            </Button>
                        )}
                    </Col>
                </Row>
            </Card>
            
            <Card style={{ overflow: 'hidden' }}>
                <Typography.Title 
                    level={3} 
                    style={{ 
                        margin: 0, 
                        marginBottom: 20, 
                        borderBottom: '2px solid #f0f0f0', 
                        paddingBottom: 12,
                        color: '#595959',
                        fontWeight: 600
                    }}
                >
                    Lançamentos Realizados
                </Typography.Title>
                {loading ? (
                    <div style={{ 
                        display: 'flex', 
                        justifyContent: 'center', 
                        alignItems: 'center', 
                        height: '200px' 
                    }}>
                        <Spin size="large" tip="Carregando dados..." />
                    </div>) :
                    <div style={{ 
                        overflowX: 'auto',
                        width: '100%',
                        maxWidth: '100%'
                    }}>
                        <LancadosTable data={pcsLancadosData}/>
                    </div>
                }
            </Card>
        </Space>
    );
}

export default LancaPC;