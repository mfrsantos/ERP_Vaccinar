import { Card, Typography, Spin, Result } from 'antd';
import {useEffect, useState} from 'react'
import TabelaMensal from '../Components/TabelaMensal';
import type { PlanilhaRow } from '../Interfaces/rowPlanilha';
import AppConfig from '../Config/AppConfig';

const setor = AppConfig.setor;

const mapKeysToTable = (data: any) => {
    return data.map((row: PlanilhaRow, index: number) => {
        return {
            ...row,
            key: index + 1
        };
    });
};

function TabelaMensalSection() {
    const [table, setTable] = useState<PlanilhaRow[]>([]);
    const [editTable, setEditTable] = useState<PlanilhaRow[]>([]);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);

    const handleAdd = () => {
        var newtb = [...table];
        newtb.push({
            key: newtb.length + 1,
            filial: '010001',
            periodicidade: 'mensal',
            cod_fornecedor: '000001',
            cod_produto: '7000005',
            fornecedor: 'Padrão',
            faturamento: '1',
            cc: '010101',
            vencimento: '20',
            valor_item: '100.00',
            lancamento: 'info',
            obs: 'novo item'
        })
        newtb = mapKeysToTable(newtb)
        setEditTable(newtb)
    }

    const handleRemove = (key: React.Key) => {
        var newData = table.filter((item: any) => item.key !== key);
        newData = mapKeysToTable(newData)
        setEditTable(newData);
    };

    useEffect(() => {
        async function fetchData() {
            try {
                setLoading(true);
                
                const apiUrl = `${AppConfig.locations.api.tabelaMensal}/${setor}`
                const response = await fetch(apiUrl, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                    }
                });
                const data = await response.json();

                if (!response.ok) {
                    if (data.detail.tipo === 'setor_nao_possui_planilha') {
                        setError('Setor não possui planilha');
                        return
                    } else {
                        setError('Erro ao buscar dados');
                        return   
                    }
                }
                

                if (data) {
                    const tb = data.rows.map((row: PlanilhaRow, index: number) => {
                        return {
                            ...row,
                            key: index + 1 
                        };
                    });

                    setTable(tb);
                } else {
                    console.error('Invalid data structure:', data);
                    setError('Invalid data structure received from API');
                }
            } catch (error) {
                console.error('Error fetching data:', error);
                setError(error instanceof Error ? error.message : 'Unknown error occurred');
            } finally {
                setLoading(false);
            }
        }

        fetchData();
    }, [])

    useEffect(() => {
        async function sendNewPlanilhatoServer() {
            setTable(editTable)
            
            const sendTable = editTable.map((row: any) => {
                row.valor_item = row.valor_item.toString().replace(',', '.');
                const { key, ...rowWithoutKey } = row; 
                return rowWithoutKey;
            });

            try {
                await fetch(
                    AppConfig.locations.api.novaTabelaMensal,
                    {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            setor: setor,
                            rows: sendTable
                        })
                    }
                );
            } catch (error) {
                console.error('Error sending data:', error);
            }
        }

        if (editTable.length > 0) { 
            sendNewPlanilhatoServer();
        }
    }, [editTable]);

    if (loading) {
        return (
            <>
             <Typography.Title    
             level={2}             
                style={{ 
                    margin: 0, 
                    marginLeft: 20, 
                    borderBottom: '3px solid #1890ff', 
                    paddingBottom: 16,
                    background: 'linear-gradient(135deg, #1890ff 0%, #722ed1 100%)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                    backgroundClip: 'text'
                }}>
                    Tabela Mensal do Setor
                </Typography.Title>
            <Card style={{marginTop: 15}}>
               
                <div style={{ 
                    display: 'flex', 
                    justifyContent: 'center', 
                    alignItems: 'center', 
                    height: '200px' 
                }}>
                    <Spin size="large" tip="Carregando dados..." />
                </div>
            </Card>
            </>
        );
    }

    if (error) {
        const getErrorDetails = (errorMessage: string) => {
            if (errorMessage === 'Setor não possui planilha') {
                return {
                    status: 'info',
                    title: 'Nenhuma Planilha Encontrada',
                    subTitle: 'Este setor ainda não possui uma planilha mensal cadastrada.',
                    icon: '📋'
                };
            }
            return {
                status: 'error',
                title: 'Erro ao Carregar Dados',
                subTitle: 'Ocorreu um problema ao buscar as informações da tabela mensal.',
                icon: '⚠️'
            };
        };

        const errorDetails = getErrorDetails(error);

        return (
            <>
            <Typography.Title level={2}                 
                style={{ 
                    margin: 0, 
                    marginLeft: 20, 
                    borderBottom: '3px solid #1890ff', 
                    paddingBottom: 16,
                    background: 'linear-gradient(135deg, #1890ff 0%, #722ed1 100%)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                    backgroundClip: 'text'
                }}>
                Tabela Mensal do Setor
                </Typography.Title>
            <Card style={{marginTop: 15}}>
                
                <Result
                    status={errorDetails.status as any}
                    title={errorDetails.title}
                    subTitle={errorDetails.subTitle}
                    style={{
                        padding: '40px 20px'
                    }}
                />
            </Card>
            </>
        );
    }

    return (
        <>
        <Typography.Title level={2}                 
            style={{ 
                    margin: 0, 
                    marginLeft: 20, 
                    borderBottom: '3px solid #1890ff', 
                    paddingBottom: 16,
                    marginBottom: 20,
                    background: 'linear-gradient(135deg, #1890ff 0%, #722ed1 100%)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                    backgroundClip: 'text'
                }}>
                    Tabela Mensal do Setor
            </Typography.Title>
        <Card style={{marginTop: 15}}>
            
            {table.length === 0 ? (
                <TabelaMensal 
                    rows={table}
                    handleAdd={handleAdd}
                    handleRemove={handleRemove}
                    onDataChange={(newData) => {
                        setEditTable(newData);
                    }}
                    
                />
            ) : (
                <TabelaMensal 
                    rows={table}
                    handleAdd={handleAdd}
                    handleRemove={handleRemove}
                    onDataChange={(newData) => {
                        setEditTable(newData);
                    }}
                
                />
            )}
        </Card>
        </>
    );
}

export default TabelaMensalSection;