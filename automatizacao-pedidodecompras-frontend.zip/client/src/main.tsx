import { createRoot } from 'react-dom/client'
import './index.css'
import './table-scrollbar.css'
import App from './App'

createRoot(document.getElementById('root')!).render(
  //<StrictMode>
    <App />
  //</StrictMode>
)
