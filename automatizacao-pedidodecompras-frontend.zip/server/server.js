const express = require('express');
const path = require('path');
const app = express();

app.use(express.static(path.join(__dirname, 'dist')));

app.get('*', function (req, res) {
  console.log('Registrada requisição para o app:', req.path);
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

console.log('Iniciando execução do App...')
app.listen(8000);